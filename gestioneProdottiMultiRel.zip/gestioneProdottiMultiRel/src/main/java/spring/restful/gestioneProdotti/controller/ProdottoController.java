package spring.restful.gestioneProdotti.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import spring.restful.gestioneProdotti.model.*;
import spring.restful.gestioneProdotti.repository.*;

@RestController
@RequestMapping("api/prodotti")
public class ProdottoController {
	
	/**
	 * DI: Dependency Injection -> chiedo a Spring di iniettare nella variabile un riferimento
	 * di classe anonima del tipo ProdottoRepository
	 * Spring ci inietta un oggetto i cui metodi risultano già implementati da Hibernate
	 * */
	@Autowired
	ProdottoRepository pr;
	
	@Autowired
	CategoriaRepository cr;
	
	@Autowired
	MarcaRepository mr;
	
	@PostMapping("/registrazione")
	public String registrazione(@RequestBody Prodotto prodotto) {
		Categoria categoria = cr.findById(prodotto.getCategoria().getId()).orElseThrow();
		Marca marca = mr.findById(prodotto.getMarca().getId()).orElseThrow();
		prodotto.setCategoria(categoria);
		prodotto.setMarca(marca);
		pr.save(prodotto);
		return "Inserimento avvenuto con successo";
	}
	
	@GetMapping("/leggi")
	public List<Prodotto> leggi() {
		return pr.findAll();
	}
	
	@GetMapping("/leggi/{id}")
	public Optional<Prodotto> leggi(@PathVariable Long id) {
		return pr.findById(id);
	}
	
	 @PutMapping("/modifica")
	 public String modifica(@RequestBody Prodotto prodotto) {
		 if(pr.existsById(prodotto.getId())) {
			 pr.save(prodotto);
			 return "Modifica avvenuta con successo";
		 }
		 return "Modifica annullata";
	 }
	 
	 @DeleteMapping("/rimozione/{id}")
	 public String rimozione(@PathVariable Long id) {
		 if(pr.existsById(id)) {
			 pr.deleteById(id);
			 return "Rimozione avvenuta con successo";
		 }
		 return "Prodotto non trovato";
	 }
}
