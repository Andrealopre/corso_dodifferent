package spring.restful.gestioneProdotti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import spring.restful.gestioneProdotti.model.Marca;
import spring.restful.gestioneProdotti.repository.MarcaRepository;

@RestController
@RequestMapping("api/marche")
public class MarcaController {
	@Autowired
	MarcaRepository mr;
	
	@GetMapping("/leggi")
	public List<Marca> leggi() {
		return mr.findAll();
	}
	
	@PostMapping("/registrazione")
	public String registrazione(@RequestBody Marca marca) {
		mr.save(marca);
		return "Marca inserita con successo";
	}
}
