package spring.restful.gestioneProdotti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import spring.restful.gestioneProdotti.model.Categoria;
import spring.restful.gestioneProdotti.repository.*;

@RestController
@RequestMapping("api/categorie")
public class CategoriaController {
	@Autowired
	CategoriaRepository cr;
	
	@GetMapping("/leggi")
	public List<Categoria> leggi() {
		return cr.findAll();
	}
	
	@PostMapping("/registrazione")
	public String registrazione(@RequestBody Categoria categoria) {
		cr.save(categoria);
		return "Categoria inserita con successo";
	}
}
