package spring.restful.gestioneProdotti.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="prodotti")
public class Prodotto {
	@Id //pk
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, length=30, unique=true)
	private String nomeProdotto;
	
	@Column(nullable=false, length=20)
	private String codiceMercelogico;
	
	@Column
	private String descrizione;
	
	@Column
	private int quantita;
	
	@Column
	private double prezzo;
	
	@ManyToOne
	@JoinColumn(name = "id_marca")
	private Marca marca;
	
	@ManyToOne
	@JoinColumn(name = "id_categoria")
	private Categoria categoria;
}
