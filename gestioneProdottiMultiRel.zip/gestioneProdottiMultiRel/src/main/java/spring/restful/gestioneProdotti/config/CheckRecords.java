package spring.restful.gestioneProdotti.config;

import java.util.List;

import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.*;

import spring.restful.gestioneProdotti.model.*;
import spring.restful.gestioneProdotti.repository.*;

@Configuration
public class CheckRecords implements ApplicationRunner {
	
	@Autowired
	private MarcaRepository mr;
	
	@Autowired
	private CategoriaRepository cr;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("Stampa eseguita prima che l'app sia in ascolto");
		this.checkMarche();
		this.checkCategorie();
	}
	
	private void checkMarche() {
		List<Marca> marche = mr.findAll();
		if(marche.isEmpty()) {
			Marca marca = new Marca();
			marca.setNomeMarca("Nike");
			mr.save(marca);
			marca = new Marca();
			marca.setNomeMarca("Adidas");
			mr.save(marca);
			marca = new Marca();
			marca.setNomeMarca("Puma");
			mr.save(marca);
			System.out.println("Marche inserite");
		} else {
			System.out.println("Marche caricate");
		}
	}
	
	private void checkCategorie() {
		List<Categoria> categorie = cr.findAll();
		if(categorie.isEmpty()) {
			Categoria categoria = new Categoria();
			categoria.setNomeCategoria("Abbigliamento");
			cr.save(categoria);
			categoria = new Categoria();
			categoria.setNomeCategoria("Attrezzatura");
			cr.save(categoria);
			System.out.println("Categorie inserite");
		} else {
			System.out.println("Categorie caricate");
		}
	}
}
