package spring.restful.gestioneProdotti.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name="categorie")
public class Categoria {
	@Id //pk
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, length=20)
	private String nomeCategoria;
}
